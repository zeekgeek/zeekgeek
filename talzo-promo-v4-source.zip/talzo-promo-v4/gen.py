import sys, json, soundfile as sf
from kokoro_onnx import Kokoro
k=Kokoro('kokoro.onnx','voices.bin')
voice=sys.argv[1]
lines=json.load(open('script.json'))
out={}
for key,txt in lines.items():
    a,sr=k.create(txt,voice=voice,speed=1.06,lang='en-us')
    sf.write(f'{voice}_{key}.wav',a,sr); out[key]=round(len(a)/sr,2)
print(json.dumps(out))
