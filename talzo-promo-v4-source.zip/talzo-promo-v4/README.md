# Talzo promo v4 (with intro) - source

1920x1080, 30fps, 76.3s. HTML/JS animation rendered frame-by-frame with Playwright, then ffmpeg.

## Files
- promo.html: all scenes. `seek(t, bg)` draws one frame. `window.MAP` maps animation time to real video time (keeps visuals in sync with the voiceover).
- render.js: `node render.js stills 3,10` (preview PNGs) or `node render.js frames [start] [end]` (PNG sequence in frames/).
- script.json: voiceover lines s0a...s6.
- gen.py: Kokoro TTS (kokoro-onnx). Voice af_heart, speed 1.06. Model files: github.com/thewh1teagle/kokoro-onnx releases (model-files-v1.0: kokoro-v1.0.onnx, voices-v1.0.bin). Run: `python3 gen.py af_heart`
- music76.py: synthesized music bed (numpy/scipy), writes music76.wav.

## Voice placement (seconds into video)
s0a 0.5 | s0b 5.0 | s0c 15.3 | s1 21.6 | s2 29.0 | s3 40.4 | s4 53.3 | s5 60.4 | s6 69.6

## Build
1. npm i playwright-core; pip install kokoro-onnx soundfile numpy scipy
2. python3 gen.py af_heart; python3 music76.py
3. node render.js frames  (split ranges across processes to go faster)
4. Mix voice: adelay each line to the times above, amix, loudnorm I=-16. Music at volume 0.26 with sidechaincompress ducking under the voice.
5. ffmpeg -framerate 30 -i frames/f%05d.png -i mix76.wav -c:v libx264 -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -shortest out.mp4

If a line changes length, update its start time above and the matching MAP points in promo.html.
