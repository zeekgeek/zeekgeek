import json, soundfile as sf
from kokoro_onnx import Kokoro
from kokoro_onnx.tokenizer import Tokenizer
FIX={'tˈæltsoʊ':'tˈælzoʊ','ɐfˈɪlɪˌeɪt':'ɐfˈɪliət'}
k=Kokoro('kokoro.onnx','voices.bin'); tk=Tokenizer(); s=json.load(open('script.json')); out={}
for key,txt in s.items():
    ph=tk.phonemize(txt,'en-us')
    for a,b in FIX.items(): ph=ph.replace(a,b)
    a,sr=k.create(ph,voice='af_heart',speed=1.06,is_phonemes=True)
    sf.write(f'af_heart_{key}.wav',a,sr); out[key]=round(len(a)/sr,2)
    print(key,out[key],ph,flush=True)
