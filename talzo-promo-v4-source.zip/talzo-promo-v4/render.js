const { chromium } = require('playwright-core');
const fs=require('fs');
(async()=>{
  const mode=process.argv[2]; // 'stills' or 'frames'
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:1920,height:1080}});
  await p.goto('file://'+__dirname+'/promo.html');
  await p.waitForFunction('window.READY===true');
  if(mode==='stills'){
    const ts=(process.argv[3]||'').split(',').map(Number);
    fs.mkdirSync('stills',{recursive:true});
    const MAP=await p.evaluate('MAP');const inv=T=>{for(let j=1;j<MAP.length;j++){const [o0,r0]=MAP[j-1],[o1,r1]=MAP[j];if(T<=r1)return o0+(o1-o0)*(T-r0)/(r1-r0)}return MAP[MAP.length-1][0]};for(const t of ts){await p.evaluate(([t,b])=>seek(t,b),[inv(t),t]);await p.screenshot({path:`stills/t${t}.png`});}
  } else {
    const fps=30,MAP=await p.evaluate('MAP');const dur=MAP[MAP.length-1][1];const inv=T=>{for(let j=1;j<MAP.length;j++){const [o0,r0]=MAP[j-1],[o1,r1]=MAP[j];if(T<=r1)return o0+(o1-o0)*(T-r0)/(r1-r0)}return MAP[MAP.length-1][0]};fs.mkdirSync('frames',{recursive:true});
    const n=Math.round(dur*fps);
    const i0=+(process.argv[3]||0),i1=Math.min(n,+(process.argv[4]||n));for(let i=i0;i<i1;i++){await p.evaluate(([t,b])=>seek(t,b),[inv(i/fps),i/fps]);await p.screenshot({path:`frames/f${String(i).padStart(5,'0')}.png`});}
    console.log('frames',n);
  }
  await b.close();
})();
