import numpy as np, scipy.signal as sg, scipy.io.wavfile as wf
SR=48000; D=76.3; N=int(SR*D); t=np.arange(N)/SR
out=np.zeros((N,2))
def note(m): return 440*2**((m-69)/12)
def saw(f,tt): return 2*((tt*f)%1)-1
def lp(x,fc): b,a=sg.butter(2,fc/(SR/2)); return sg.lfilter(b,a,x)
def env(n,a,r):
    e=np.ones(n); ai=min(n,int(a*SR)); ri=min(n,int(r*SR))
    e[:ai]=np.linspace(0,1,ai); e[-ri:]*=np.linspace(1,0,ri); return e
bpm=120; beat=60/bpm; bar=4*beat
# chords: Am F C G (minor 9-ish voicings) each 1 bar (2s)
prog=[[57,60,64,71],[53,57,60,67],[48,55,64,67],[55,59,62,69]]
bass=[45,41,48,43]
i=0; s=0.0
while s<D:
    ch=prog[i%4]; n=int(min(bar,D-s)*SR); tt=np.arange(n)/SR; a=int(s*SR)
    pad=np.zeros(n)
    for m in ch:
        for det in (-0.08,0.08): pad+=saw(note(m)*2**(det/12),tt)
    pad=lp(pad,1400+600*np.sin(s))*env(n,0.25,0.4)*0.05
    out[a:a+n,0]+=pad; out[a:a+n,1]+=np.roll(pad,240)
    b=np.sin(2*np.pi*note(bass[i%4]-12)*tt)*env(n,0.02,0.3)*0.22
    out[a:a+n]+=b[:,None]
    i+=1; s+=bar
# drums from 0.5s, quieter intro; pluck arp
def kick(at,g=1):
    n=int(.35*SR); tt=np.arange(n)/SR; f=50+90*np.exp(-tt*30)
    k=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*9)*0.55*g; a=int(at*SR); e=min(N,a+n); out[a:e]+=k[:e-a,None]
def hat(at,g=1):
    n=int(.06*SR); h=np.random.default_rng(int(at*1000)).standard_normal(n); h=sg.lfilter(*sg.butter(2,7000/(SR/2),'high'),h)*np.exp(-np.arange(n)/SR*60)*0.08*g
    a=int(at*SR); e=min(N,a+n); out[a:e,0]+=h[:e-a]*0.8; out[a:e,1]+=h[:e-a]
def pluck(at,m,g=1):
    n=int(.4*SR); tt=np.arange(n)/SR; p=(np.sin(2*np.pi*note(m)*tt)+0.3*np.sin(4*np.pi*note(m)*tt))*np.exp(-tt*9)*0.07*g
    a=int(at*SR); e=min(N,a+n); out[a:e]+=p[:e-a,None]
bt=0.0; k=0
while bt<D-1.2:
    g=0.55 if bt<21.2 else 1.0
    if bt>=1.0: kick(bt,g)
    hat(bt+beat/2,g)
    ch=prog[int(bt//bar)%4]
    pluck(bt,ch[k%4]+12,g); pluck(bt+beat/2,ch[(k+2)%4]+12,g*0.7)
    bt+=beat; k+=1
# whooshes into scene changes
def whoosh(at,dur=0.6,g=1):
    n=int(dur*SR); w=np.random.default_rng(int(at*7)).standard_normal(n)
    fc=np.linspace(400,6000,n); y=np.zeros(n); # sweep via chunks
    for c in range(0,n,1200):
        b,a=sg.butter(2,[max(100,fc[c]*0.6)/(SR/2),min(SR/2-100,fc[c]*1.4)/(SR/2)],'band'); y[c:c+1200]=sg.lfilter(b,a,w[c:c+1200])
    y*=np.sin(np.linspace(0,np.pi,n))**2*0.25*g
    a=int((at-dur*0.8)*SR); e=min(N,a+n); out[a:e,0]+=y[:e-a]; out[a:e,1]+=y[:e-a]*0.9
for at in (21.2,28.6,40.0,52.9,60.0,69.3): whoosh(at)
# impact at logo + shimmer
def impact(at):
    n=int(1.6*SR); tt=np.arange(n)/SR; y=np.sin(2*np.pi*(40+40*np.exp(-tt*12))*tt)*np.exp(-tt*2.5)*0.6
    sh=sum(np.sin(2*np.pi*note(m)*tt) for m in (81,84,88,93))*np.exp(-tt*1.8)*0.03
    a=int(at*SR); e=min(N,a+n); out[a:e]+=(y+sh)[:e-a,None]
impact(69.3); impact(26.0); impact(0.3)
# master
fade=np.ones(N); fade[-int(1.5*SR):]=np.linspace(1,0,int(1.5*SR)); fade[:int(.3*SR)]=np.linspace(0,1,int(.3*SR))
out*=fade[:,None]; out=np.tanh(out*1.3); out/=np.abs(out).max()/0.89
wf.write('music76.wav',SR,(out*32767).astype(np.int16))
print('ok')
