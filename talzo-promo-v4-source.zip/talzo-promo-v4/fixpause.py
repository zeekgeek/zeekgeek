import numpy as np, soundfile as sf, sys
from kokoro_onnx import Kokoro
from kokoro_onnx.tokenizer import Tokenizer
FIX={'tˈæltsoʊ':'tˈælzoʊ','ɐfˈɪlɪˌeɪt':'ɐfˈɪliət'}
k=Kokoro('kokoro.onnx','voices.bin'); tk=Tokenizer()
def say(t):
    ph=tk.phonemize(t,'en-us')
    for a,b in FIX.items(): ph=ph.replace(a,b)
    a,sr=k.create(ph,voice='af_heart',speed=1.06,is_phonemes=True); return a,sr
def trim(a,th=-45):
    e=20*np.log10(np.abs(a)/np.abs(a).max()+1e-9); idx=np.where(e>th)[0]; return a[max(0,idx[0]-240):idx[-1]+480]
LINES={
 's2':[("That's not a partnership.",0.55),("That's a toll booth.",0.45),("Talzo is one flat price. No percentage fees. No caps. Sell ten times more, and your bill stays exactly the same.",0)],
 's4':[("Best of all — we never touch your money.",0.35),("No middleman.",0.35),("No mystery fees.",0.38),("You pay your partners directly.",0)],
 's6':[("Talzo.",0.5),("Affiliate marketing — made simple.",0.45),("Get started today at Talzo dot app.",0)],
}
for key,segs in LINES.items():
    out=[]
    for txt,gap in segs:
        a,sr=say(txt); out.append(trim(a)); out.append(np.zeros(int(gap*sr),dtype=np.float32))
    y=np.concatenate(out); sf.write(f'af_heart_{key}.wav',y,sr); print(key,round(len(y)/sr,2))
